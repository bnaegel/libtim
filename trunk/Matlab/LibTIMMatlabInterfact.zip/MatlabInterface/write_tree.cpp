/*=================================================================
 *
 * write_tree.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * write_tree writes the tree to disk (.DOT format), for example:
 *
 *   write_tree(handle, filename);
 *
 * where handle is the handle to an initialised component tree and 
 * filename is a string containing the name of the file to which the
 * component tree should be written.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use any of the processing functions provided by LibTIM, e.g.:
 *
 *   constrast_filter(handle, int minContrast, int maxContrast);
 *
 * You can then write the tree to disk (.DOT format):
 *
 *   write_tree(handle, filename);
 * 
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"

using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/
/************************ Wrapping Function ******************************/
/*************************************************************************/

mxArray *writeTree (const mxArray *tree_p, const mxArray *filename_p) {
    
    // Get the filename
    unsigned int buflen = (mxGetM(filename_p) * mxGetN(filename_p)) + 1;
    
    char *input_cmd     = (char*)mxCalloc(buflen, sizeof(char));
    
    if (mxGetString(filename_p, input_cmd, buflen) != 0)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:insufficientMemory", "Not enough memory--filename could not be retrieved.");

    
    // Get tree
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    return mxCreateDoubleScalar((double)tree.writeTree(input_cmd));
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if (nrhs != 2) 
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "write_tree(tree, filename).");
    
    plhs[0] = writeTree(prhs[0], prhs[1]);
    
}