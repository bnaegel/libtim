/*=================================================================
 *
 * reconstruct_image.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * reconstruct_image reconstructs the image which is represented by a 
 * component tree:
 *
 *   img = reconstruct_image(handle, METHOD);
 *
 * where handle is the handle to an initialised component tree, img is 
 * the resulting image (UINT8) and where METHOD ? {1, 2, 3} (optional),
 * such that
 *  
 *   1 = DIRECT;
 *   2 = MIN;
 *   3 = MAX.
 *
 * If no method is supplied then reconstruct_image defaults to DIRECT.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use any of the processing functions provided by LibTIM, e.g.:
 *
 *   constrast_filter(handle, int minContrast, int maxContrast);
 *
 * You can then reconstruct the image from the processed tree (see 
 * above for options):
 *
 *   img = reconstruct_image(handle);
 * 
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/
/************************ Wrapping Functions *****************************/
/*************************************************************************/

mxArray *retrieveImage (const mxArray *tree_p, const mxArray *method_p) {
    
    bool     debug=false;     // Prints information to screen
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    double *method = (double *)mxGetData(method_p);
    
    Image<U8> im;
    
    switch ((int)*method)
    {
        case 1:
            im  = tree.constructImage(ComponentTree<U8>::DIRECT); break;
        case 2:
            im  = tree.constructImage(ComponentTree<U8>::MIN);    break;
        case 3:
            im  = tree.constructImage(ComponentTree<U8>::MAX);    break;
        default:
            mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "Unknown method code.");
    }
    
    if (debug) im.print();
    
    U8 *imdata_p      = im.getData();
    const TSize *size = im.getSize();
    
    mxArray *output = mxCreateNumericMatrix(*(size+1), *size, mxUINT8_CLASS, 0);
    unsigned char *out_p   = (unsigned char*)mxGetPr(output);
    
    if (debug) mexPrintf("Image Size: %d x %d\n", *(size+1), *size);
    
    if (debug) mexPrintf("Copying data...");
    
    int i;
    for (i=0; i<*size*(*(size+1)); i++){
        *(out_p+i) = *(imdata_p+i);
    }
    
    if (debug) mexPrintf("Done\n");
    
    return output;
}


// Default behavious if no method is supplied, use DIRECT
mxArray *retrieveImage (const mxArray *tree_p) {
    
    bool     debug=false;     // Prints information to screen
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    Image<U8> im  = tree.constructImage(ComponentTree<U8>::DIRECT);
    
    if (debug) im.print();
    
    U8 *imdata_p      = im.getData();
    const TSize *size = im.getSize();
    
    mxArray *output = mxCreateNumericMatrix(*(size+1), *size, mxUINT8_CLASS, 0);
    unsigned char *out_p   = (unsigned char*)mxGetPr(output);
    
    if (debug) mexPrintf("Image Size: %d x %d\n", *(size+1), *size);
    
    if (debug) mexPrintf("Copying data...");
    
    int i;
    for (i=0; i<*size*(*(size+1)); i++){
        *(out_p+i) = *(imdata_p+i);
    }
    
    if (debug) mexPrintf("Done\n");
    
    return output;
}


/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if (nrhs != 1 && nrhs != 2)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "make_image(tree_handle, method). \n\n\t1 = DIRECT, \n\t2 = MIN, \n\t3 = MAX (if omitted defaults to DIRECT).");
    
    if (nrhs == 1)
        plhs[0] = retrieveImage(prhs[0]);
    else
    {
        if( mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) )
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");
        
        plhs[0] = retrieveImage(prhs[0], prhs[1]);
    }
}