/*=================================================================
 *
 * boundingbox_filter.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * boundingbox_filter filters the bounding box of regions within an image:
 *
 *   boundingbox_filter(handle, int minBoundingbox, int maxBoundingbox);
 *
 * where handle is the handle to an initialised component tree and 
 * minBoundingbox and maxBoundingbox define the passband range of a
 * region's bounding box.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use the following syntax to perform actions on the tree:
 *   
 *   boundingbox_filter(handle, int minSize, int maxSize);
 *
 * You can then reconstruct the image from the processed tree (see 
 * reconstuct_image for options):
 *
 *   img = reconstruct_image(handle);
 *
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


// ********************************
// ********************************
// CURRENTLY FIXED TO UINT8 input
// DONT DO ANYTHING WITH ERROR CODES
// ********************************
// ********************************


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/

void boundingboxFilter (const mxArray *tree_p, const mxArray *minBB_p, const mxArray *maxBB_p) {
    
    double *minBB = (double *)mxGetData(minBB_p);
    double *maxBB = (double *)mxGetData(maxBB_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.boundingboxFilter((int)*minBB, (int)*maxBB);
    
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if (nrhs != 3)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "boundingbox_filter(tree, int minSize, int maxSize).");
    
    //if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");
    
    //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

    boundingboxFilter(prhs[0], prhs[1], prhs[2]);
}