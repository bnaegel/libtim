/*=================================================================
 *
 * CT_Interface.cpp
 *
 * Defines an interface into the Component Tree code from Matlab.
 * Keeps the component tree persistently in memory between calls until
 * the destroy function is called.
 *
 * This technique was originally developed by Mike Stevens and Coded 
 * by Tim Bailey.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * To initialise a tree use:
 *   
 *   CT_interface(image, 'Create');
 *
 * Then use the following syntax to perform actions on the tree:
 *   
 *   CT_interface(tree, command, argument(s)...);
 * 
 * where
 *
 *   command = 
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Common/Image.h"
#include "../Algorithms/ComponentTree.h"
#include "../Common/Types.h"
#include <string>
#include "U8CTree.h"


// ********************************
// ********************************
// CURRENTLY FIXED TO UINT8 input
// DONT DO ANYTHING WITH ERROR CODES
// ********************************
// ********************************


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/
/************************ Wrapping Functions *****************************/
/*************************************************************************/

void create (mxArray **out, const mxArray *img_p) {
    
    bool     debug=false;     // Prints information to screen
    
    // Wrap ComponentTree as the ObjectHandler doesn't like to deal with templates
    U8CTree *tree = new U8CTree(img_p);
    
    if (debug) tree->print();
    
    if (debug) mexPrintf("Pointer before: %#x\n", tree);
    
    ObjectHandle<U8CTree> *handle = new ObjectHandle<U8CTree>(tree);
    
    if (debug) mexPrintf("Pointer after:  %#x\n", tree);
    
    *out = handle->to_mex_handle();
}

/*************************************************************************/

void display (const mxArray *in) {
    
    U8CTree& tree = get_object<U8CTree>(in);
    tree.print();
    
}

/*************************************************************************/

void destroy (const mxArray *in) {

	destroy_object<U8CTree>(in);
    
}

/*************************************************************************/

void areaFilter (const mxArray *tree_p, const mxArray *area_p) {
    
    double *minArea = (double *)mxGetData(area_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    //std::cout<<(int)*minArea<<std::endl; 
             
    tree.areaFilter((int)*minArea);
    
}

void areaFilter (const mxArray *tree_p, const mxArray *minarea_p, const mxArray *maxarea_p) {
    
    double *minArea = (double *)mxGetData(minarea_p);
    double *maxArea = (double *)mxGetData(maxarea_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    //std::cout<<(int)*minArea<<std::endl; 
             
    tree.areaFilter((int)*minArea, (int)*maxArea);
    
}

/*************************************************************************/

mxArray *retrieveImage (const mxArray *tree_p) {
    
    bool     debug=false;     // Prints information to screen
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    Image<U8> im  = tree.constructImage(ComponentTree<U8>::DIRECT);
    
    if (debug) im.print();
    
    U8 *imdata_p      = im.getData();
    const TSize *size = im.getSize();
    
    mxArray *output = mxCreateNumericMatrix(*(size+1), *size, mxDOUBLE_CLASS, 0);
    double *out_p   = mxGetPr(output);
    
    int i;
    for (i=0; i<*size*(*(size+1)); i++){
        *(out_p+i) = (double)*(imdata_p+i);
    }
    
    return output;
}

/*************************************************************************/

mxArray *writeTree (const mxArray *tree_p, const mxArray *filename_p) {
    
    // Get the filename
    unsigned int buflen = (mxGetM(filename_p) * mxGetN(filename_p)) + 1;
    
    char *input_cmd     = (char*)mxCalloc(buflen, sizeof(char));
    
    if (mxGetString(filename_p, input_cmd, buflen) != 0)
        mexErrMsgIdAndTxt("MATLAB:CT_Interface:insufficientMemory", "Not enough memory---filename could not be retrieved.");

    
    // Get tree
	U8CTree& tree = get_object<U8CTree>(tree_p);
    
    return mxCreateDoubleScalar((double)tree.writeTree(input_cmd));
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    bool           debug=false;     // Prints information to screen
    
    char          *input_cmd;
    unsigned int   buflen;
    size_t         mrows,ncols;
    
    
    if (nrhs == 0) 
        mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage","Bad call.");
    else{
        
        /* Second input argument must be a string. */
        if (!mxIsChar(prhs[1]))
            mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "Second input argument must be a string.");
    
        // Get the second argument, which contains the command for the
        // action to be performed
        buflen = (mxGetM(prhs[1]) * mxGetN(prhs[1])) + 1;
        
        input_cmd = (char*)mxCalloc(buflen, sizeof(char));
                
        if (mxGetString(prhs[1], input_cmd, buflen) != 0)
            mexErrMsgIdAndTxt("MATLAB:CT_Interface:insufficientMemory", "Not enough memory---command string could not be retrieved.");
        
        std::string cmd_str(input_cmd);
        
        if (debug) std::cout << "Command: " + cmd_str << std::endl;
        
        
        if (cmd_str == "Create")
        {
            if (nlhs == 0)
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "The object pointer must be returned.");
            if (nrhs != 2)
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface('Create', image).");
            
            create(&plhs[0], prhs[0]);
        }
        else if (cmd_str == "Destroy")
        {
            if (nrhs != 2) 
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface(tree, 'Destroy').");
            
            destroy(prhs[0]);
        }
        else if (cmd_str == "Display")
        {
            if (nrhs != 2) 
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface(tree, 'Display').");
            
            display(prhs[0]);
        }
        else if (cmd_str == "AreaFilter")
        {
            if ((nrhs != 3) && (nrhs != 4))
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface(tree, 'AreaFilter', int minArea) or CT_Interface(tree, 'AreaFilter', int minArea, int maxArea).");
            
            mrows = mxGetM(prhs[2]);
            ncols = mxGetN(prhs[2]);
            //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
            if( mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) )
                mexErrMsgIdAndTxt( "MATLAB:CT_Interface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

            if (nrhs == 3){
                areaFilter(prhs[0], prhs[2]);
            }
            
            if (nrhs == 4)
            {
                mrows = mxGetM(prhs[3]);
                ncols = mxGetN(prhs[3]);
                //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
                if( mxIsComplex(prhs[3]) || !(mrows==1 && ncols==1) )
                    mexErrMsgIdAndTxt( "MATLAB:CT_Interface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");
                
                areaFilter(prhs[0], prhs[2], prhs[3]);
            }
        }
        else if (cmd_str == "RetrieveImage")
        {
            if (nrhs != 2) 
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface(tree, 'RetrieveImage').");
            
             plhs[0] = retrieveImage(prhs[0]);
        }
        else if (cmd_str == "WriteTree")
        {
            if (nrhs != 3) 
                mexErrMsgIdAndTxt("MATLAB:CT_Interface:incorrectUseage", "CT_Interface(tree, 'WriteTree', filename).");
            
             plhs[0] = writeTree(prhs[0], prhs[2]);
        }
        else if (cmd_str == "Help")
            mexPrintf("\nUseage: CT_Interface(tree, command, [variables])\n\n\tCommand \t Arguments \t Returns\n"
                    "\t----------------------------------------\n"
                    "\tHelp\n"
                    "\tCreate\t\tImage (UINT8)\tTree Handle\n"
                    "\tDestroy\t\tTree Handle\n\t"
                    "Display\t\tTree Handle\n"
                    "\tAreaFilter\tMin Area (UINT8)\n"
                    "WriteTree\t\tFilename\t 1 if successful\n"
                    "\n");
        else
            mexErrMsgIdAndTxt("MATLAB:CT_Interface:commandNotRecognised", "Invalid Command.");
        
    }
}