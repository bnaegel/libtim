/*=================================================================
 *
 * compacity_filter.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * compacity_filter filters the compacity of regions within an image:
 *
 *   compacity_filter(handle, int minCompacity);
 * 
 * or
 *
 *   compacity_filter(handle, int minCompacity, int maxCompacity);
 *
 * where handle is the handle to an initialised component tree and 
 * minCompacity and maxCompacity define the passband range of a region's
 * compactness.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use the following syntax to perform actions on the tree:
 *   
 *   compacity_filter(handle, int minCompacity, int maxCompacity);
 *
 * You can then reconstruct the image from the processed tree (see 
 * reconstuct_image for options):
 *
 *   img = reconstruct_image(handle);
 *
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


// ********************************
// ********************************
// CURRENTLY FIXED TO UINT8 input
// DONT DO ANYTHING WITH ERROR CODES
// ********************************
// ********************************


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/

void compacityFilter (const mxArray *tree_p, const mxArray *minCompacity_p, const mxArray *maxCompacity_p) {
    
    double *minCompacity = (double *)mxGetData(minCompacity_p);
    double *maxCompacity = (double *)mxGetData(maxCompacity_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.boundingboxFilter((int)*minCompacity, (int)*maxCompacity);
    
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if (nrhs != 3)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "compacity_filter(tree, int minCompacity, int maxCompacity).");

    //if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

    //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

    compacityFilter(prhs[0], prhs[1], prhs[2]);
}