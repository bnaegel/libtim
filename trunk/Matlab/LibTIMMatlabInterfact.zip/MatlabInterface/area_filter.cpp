/*=================================================================
 *
 * area_filter.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * area_filter filters the area of regions within an image:
 *
 *   area_filter(handle, int minArea);
 * 
 * or
 *
 *   area_filter(handle, int minArea, int maxArea);
 *
 * where handle is the handle to an initialised component tree and minArea 
 * and maxArea define the passband range of a region's area.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use the following syntax to perform actions on the tree:
 *
 *   area_filter(handle, int minArea, int maxArea);
 *
 * You can then reconstruct the image from the processed tree (see 
 * reconstuct_image for options):
 *
 *   img = reconstruct_image(handle);
 *
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


// ********************************
// ********************************
// CURRENTLY FIXED TO UINT8 input
// DONT DO ANYTHING WITH ERROR CODES
// ********************************
// ********************************


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/

void areaFilter (const mxArray *tree_p, const mxArray *area_p) {
    
    double *minArea = (double *)mxGetData(area_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.areaFilter((int)*minArea);
    
}

void areaFilter (const mxArray *tree_p, const mxArray *minarea_p, const mxArray *maxarea_p) {
    
    double *minArea = (double *)mxGetData(minarea_p);
    double *maxArea = (double *)mxGetData(maxarea_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.areaFilter((int)*minArea, (int)*maxArea);
    
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if ((nrhs != 2) && (nrhs != 3))
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "area_filter(tree, int minArea) or area_filter(tree, int minArea, int maxArea).");
    
    //if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

    if (nrhs == 2){
        areaFilter(prhs[0], prhs[1]);
    }

    if (nrhs == 3)
    {
        //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
        if( mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) )
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

        areaFilter(prhs[0], prhs[1], prhs[2]);
    }
}