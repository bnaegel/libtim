/*=================================================================
 *
 * create_tree.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * create_tree initialises a tree from an image:
 *
 *   handle = create_tree(img);
 *
 * where handle is the handle to an initialised component tree and img is 
 * the image in UINT8 format.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use any of the processing functions provided by LibTIM, e.g.:
 *
 *   constrast_filter(handle, int minContrast, int maxContrast);
 *
 * You can then reconstruct the image from the processed tree (see 
 * reconstuct_image for options):
 *
 *   img = reconstruct_image(handle);
 *
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/
/************************ Wrapper Functions ******************************/
/*************************************************************************/

void create (mxArray **out, const mxArray *img_p) {
    
    bool     debug=false;     // Prints information to screen
    
    // Wrap ComponentTree as the ObjectHandler doesn't like to deal with templates
    U8CTree *tree = new U8CTree(img_p);
    
    if (debug) tree->print();
    
    if (debug) mexPrintf("Pointer before: %#x\n", tree);
    
    ObjectHandle<U8CTree> *handle = new ObjectHandle<U8CTree>(tree);
    
    if (debug) mexPrintf("Pointer after:  %#x\n", tree);
    
    *out = handle->to_mex_handle();
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    
    if (nlhs == 0)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "The object pointer must be returned.");
    if (nrhs != 1)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "Useage: handle = create_image(image).");

    create(&plhs[0], prhs[0]);
}