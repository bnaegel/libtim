/*=================================================================
 *
 * U8CTree.h
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * The U8CTree class defines a component tree object, which includes the 
 * component tree data structure and functional interface between 
 * LibTIMMatlab and the original LibTIM C++ code. Due to the persistance 
 * code not being compatible with the templates defined within LibTIM this 
 * class hard codes an 8-bit unsigned integer data type for the component 
 * tree.
 *
 */


#define	SUCCESS			0
#define	MALLOCFAIL		-1
#define IMPROPERDIMS	-2


namespace LibTIMMatlab {

    using namespace LibTIM;
    
    class U8CTree {

        public:
            
            /************************************/
            /* Constructor/Destructor Functions */
            /************************************/
            
            U8CTree(const mxArray *img_p, FlatSE connexity)
            {
                bool     debug=false;     // Prints information to screen

                Image<U8> im;

                // Rerieve the image data from Matlab
                if (getImage(img_p, &im) != 0) mexErrMsgTxt("Error importing image.");

                if (debug) im.print();

                // Construct a component-tree on the image using the Salembier method
                tree = new ComponentTree<U8>(im, connexity);

                if (debug) tree->print();
            }
            U8CTree(const mxArray *img_p) 
            {

                bool     debug=false;     // Prints information to screen

                Image<U8> im;

                // Rerieve the image data from Matlab
                if (getImage(img_p, &im) != 0) mexErrMsgTxt("Error importing image.");

                if (debug) im.print();

                // Construct a component-tree on the image using the Salembier method
                tree = new ComponentTree<U8>(im);

                if (debug) tree->print();
            }

            ~U8CTree() {
                delete tree;
            }
            
            /************************************/
            /*        Filtering Functions       */
            /************************************/

            void areaFilter(int minArea){

                tree->areaFiltering(minArea);
            }
            
            void volumeFilter(int minVol){

                tree->volumicFiltering(minVol);
            }
            
            void contrastFilter(int minContrast){

                tree->contrastFiltering(minContrast);
            }
            

            void areaFilter(int minArea, int maxArea){

                tree->areaFiltering(minArea, maxArea);

            }
            
            void volumeFilter(int minVol, int maxVol){

                tree->volumicFiltering(minVol, maxVol);

            }
            
            void contrastFilter(int minContrast, int maxContrast){

                tree->contrastFiltering(minContrast, maxContrast);

            }
            
            void complexityFilter(int minComplexity, int maxComplexity){

                tree->complexityFiltering(minComplexity, maxComplexity);

            }

            void boundingboxFilter(int minBB, int maxBB){

                tree->boundingBoxFiltering(minBB, maxBB);

            }
            
            void compacityFilter(int minCompacity, int maxCompacity){

                tree->compacityFiltering(minCompacity, maxCompacity);

            }
            
            
            /************************************/
            /*           I/O Functions          */
            /************************************/
            
            Image<U8> constructImage(ComponentTree<U8>::ConstructionDecision decision){

                Image<U8> res = tree->constructImage(decision);

                return res;
            }

            int writeTree(const char *filename){

                return tree->writeDot(filename);
            }
            
            void print() {
                tree->print();
            }
            
            void printSize() {
                tree->printSize();
            }
            

        private:

            ComponentTree<U8> *tree;

            int getImage( const mxArray *img_in, Image<U8> *im );
    };

    int U8CTree::getImage( const mxArray *img_in, Image<U8> *im )
    {
        bool     debug=false;     // Prints information to screen

        int      index;
        TSize    size [3];
        U8       *data;

        if( mxGetNumberOfDimensions(img_in) != 2 )
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotCorrectDimensions", "The image must be two dimensional.");
        
        if (mxIsClass(img_in, "sparse"))
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:incorrectInputType", "The image must not be sparse.");
        
        if (!mxIsClass(img_in, "uint8"))
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:incorrectInputType", "The image must be of 8-bit unsigned integer type.");
        
        // Read and set the size of each dimension of the image
        // (need to flip the matrix to be correct in c)
        size[1] = *mxGetDimensions(img_in);
        size[0] = *(mxGetDimensions(img_in)+1);
        size[2] = 1;
        im->setSize(size);
        

        if (debug) mexPrintf("Width: %d, Height: %d, Depth: %d\n", size[0],size[1],size[2]);
        if (debug) mexPrintf("Number of Data Points: %d \n", mxGetNumberOfElements(img_in));



        data = (U8 *)mxGetData(img_in);

        if (debug)
        {
            for (index=0; index < mxGetNumberOfElements(img_in); ++index)
            {
                mexPrintf("%d ", *(data+index));
            }
            mexPrintf("\n");
        }

        im->pass(size, data, im);

        return SUCCESS;
    }
}