function success = make


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %
 % make.m
 %
 % LibTIMMatlab defines an interface into the Component Tree package 
 % LibTIM from Matlab.
 %
 % A component tree can be initialised upon an image, and is persistantly
 % kept in memory between calls (the destroy_tree function removes the
 % tree from memory).
 %
 % The current implementation only handles a image formed using the UINT8 
 % data type.
 %
 % Thomas Lampert 2012
 %
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %
 %
 % make.m builds the MEX files that are necessary for the LibTIM 
 % Matlab interface.
 % 
 % 
 % To initialise a tree use:
 %   
 %   handle = create_tree(image);
 %
 % Then use any of the processing functions provided by LibTIM, e.g.:
 %   
 %   constrast_filter(handle, int minContrast);
 %
 % or
 %
 %   constrast_filter(handle, int minContrast, int maxContrast);
 %
 % You can then reconstruct the image from the processed tree (see 
 % reconsutruct image for options):
 %
 %   img = reconstruct_image(handle);
 % 
 % Finally, to remove the tree from memory use:
 %
 %   destroy_tree(handle);
 %
 %
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 
 
fprintf('Compiling Mex Files...');

success = 1;

filenames = {'area_filter.cpp', 'boundingbox_filter.cpp', ...
             'compacity_filter.cpp', 'complexity_filter.cpp', ...
             'contrast_filter.cpp', 'create_tree.cpp', ...
             'destroy_tree.cpp', 'print_tree.cpp', ...
             'print_treesize.cpp', 'reconstruct_image.cpp', ...
             'volume_filter.cpp', 'write_tree.cpp'};

for i = 1:numel(filenames)
    try
        mex([filenames{i}]);
    catch err
        warning('MATLAB:LibTIMMatlabInterface:compileError', ['Could not compile ' filenames{i} '.']);
        success = 0;
    end
end

if success
    fprintf('Done\n');
else
    fprintf('One or more mex files were not compiled.\n');
end