/*=================================================================
 *
 * constrast_filter.cpp
 *
 * LibTIMMatlab defines an interface into the Component Tree package 
 * LibTIM from Matlab.
 *
 * A component tree can be initialised upon an image, and is persistantly
 * kept in memory between calls (the destroy_tree function removes the
 * tree from memory).
 *
 * The current implementation only handles a image formed using the UINT8 
 * data type.
 *
 * Thomas Lampert 2012
 *
 *=================================================================*/

/*
 *
 * contrast_filter filters the contrast of the tree:
 *
 *   contrast_filter(handle, int minContrast);
 * 
 * or
 *
 *   contrast_filter(handle, int minContrast, int maxContrast);
 *
 * where handle is the handle to an initialised component tree and 
 * minContrast and maxContrast define the passband range of the contrast
 * in the component tree.
 *
 *
 * Example useage
 *
 * To initialise a tree use:
 *   
 *   handle = create_tree(image);
 *
 * Then use the following syntax to perform actions on the tree:
 *
 *   contrast_filter(handle, int minContrast, int maxContrast);
 * 
 * You can then reconstruct the image from the processed tree (see 
 * reconstuct_image for options):
 *
 *   img = reconstruct_image(handle);
 *
 * Finally, to remove the tree from memory use:
 *
 *   destroy_tree(handle);
 *
 */

#include "ObjectHandle.h"
#include <mex.h>
#include "../Algorithms/ComponentTree.h"
#include "U8CTree.h"


// ********************************
// ********************************
// CURRENTLY FIXED TO UINT8 input
// DONT DO ANYTHING WITH ERROR CODES
// ********************************
// ********************************


using namespace LibTIM;
using namespace LibTIMMatlab;

/*************************************************************************/

void contrastFilter (const mxArray *tree_p, const mxArray *mincontrast_p) {
    
    double *mincontrast = (double *)mxGetData(mincontrast_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.contrastFilter((int)*mincontrast);
    
}

void contrastFilter (const mxArray *tree_p, const mxArray *mincontrast_p, const mxArray *maxcontrast_p) {
    
    double *mincontrast = (double *)mxGetData(mincontrast_p);
    double *maxcontrast = (double *)mxGetData(maxcontrast_p);
    
	U8CTree& tree = get_object<U8CTree>(tree_p);
             
    tree.contrastFilter((int)*mincontrast, (int)*maxcontrast);
    
}

/*************************************************************************/

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )     
{
    if (nrhs != 2)
        mexErrMsgIdAndTxt("MATLAB:LibTIMMatlabInterface:incorrectUseage", "contrast_filter(tree, int minContrast) or contrast_filter(tree, int minContrast, int maxContrast).");

    //if( !mxIsDouble(prhs[1]) || mxIsComplex(prhs[1]) || !(mrows==1 && ncols==1) ) 
    if( mxIsComplex(prhs[1]) || !(mxGetM(prhs[1])==1 && mxGetN(prhs[1])==1) )
        mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

    if (nrhs == 2){
        contrastFilter(prhs[0], prhs[1]);
    }

    if (nrhs == 3)
    {
        //if( !mxIsDouble(prhs[2]) || mxIsComplex(prhs[2]) || !(mrows==1 && ncols==1) ) 
        if( mxIsComplex(prhs[2]) || !(mxGetM(prhs[2])==1 && mxGetN(prhs[2])==1) )
            mexErrMsgIdAndTxt( "MATLAB:LibTIMMatlabInterface:inputNotRealScalarDouble", "Input must be a noncomplex scalar double.");

        contrastFilter(prhs[0], prhs[1], prhs[2]);
    }
}