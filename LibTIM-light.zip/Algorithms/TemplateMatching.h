#ifndef TemplateMatching_h
#define TemplateMatching_h

#include "TemplateMatching.hxx"

#endif
