#ifndef AdaptativeSE_h
#define AdaptativeSE_h

#include "AdaptativeSE.hxx"

#endif
