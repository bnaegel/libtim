#ifndef DistanceTransform_h
#define DistanceTransform_h

#include "DistanceTransform.hxx"

#endif
