#ifndef ColorProcessing_h
#define ColorProcessing_h

#include "ColorProcessing.hxx"

#endif
