#ifndef KMeans_h
#define KMeans_h

#include "KMeans.hxx"

#endif
