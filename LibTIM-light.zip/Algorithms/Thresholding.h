#ifndef Thresholding_h
#define Thresholding_h

#include "Thresholding.hxx"

#endif
