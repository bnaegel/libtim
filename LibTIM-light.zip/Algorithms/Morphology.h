#ifndef Morphology_h
#define Morphology_h

#include "Morphology.hxx"

#endif
