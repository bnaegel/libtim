#ifndef ConnectedComponents_h
#define ConnectedComponents_h

#include "ConnectedComponents.hxx"

#endif
