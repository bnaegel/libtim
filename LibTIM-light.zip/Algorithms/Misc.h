#ifndef Misc_h
#define Misc_h

#include "Misc.hxx"

#endif
