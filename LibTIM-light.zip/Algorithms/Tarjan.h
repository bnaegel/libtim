#ifndef Tarjan_h
#define Tarjan_h

#include "Tarjan.hxx"

#endif
